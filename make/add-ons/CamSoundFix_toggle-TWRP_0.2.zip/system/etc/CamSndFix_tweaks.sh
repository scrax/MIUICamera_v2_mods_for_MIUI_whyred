#!/sbin/sh

dir="/system/media/audio/ui/"

audio_fix() {
	cat <<EOF
camera_click.ogg
camera_focus.ogg
VideoRecord.ogg
VideoStop.ogg
EOF
}

busybox umount /system
busybox mount /system

echo 'Starting camera sound fix'
audio_fix | while read name ;
	do
		echo Check camera sound: "$name"
		[ -f $dir$name.bak ] && mv $dir$name.bak $dir$name || mv $dir$name $dir$name.bak ;
	done

busybox umount /system