#!/sbin/sh

shutter_files(){
	cat <<EOF
system/vendor/usr/keylayout/uinput-fpc.kl
system/vendor/usr/keylayout/uinput-goodix.kl
EOF
}

busybox umount /vendor
busybox mount /vendor

shutter_files | while read filename ;
	do
  		if [ -f $filename.bak ];
	  		then
	  			rm -rf $filename
	  			cp $filename.bak $filename
	  		else
	  			cp $filename $filename.bak
	  	fi
	  	echo 'key 96 DPAD_CENTER' > $filename
		#echo '\#key 102   HOME' >> $filename
		#echo '\#key 105   DPAD_LEFT' >> $filename
		#echo '\#key 106   DPAD_RIGHT' >> $filename
	    echo 'key 353 CAMERA' >> $filename
	done

busybox umount /vendor
