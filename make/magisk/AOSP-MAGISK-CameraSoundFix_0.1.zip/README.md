# **FPShutter for whyred (Redmi note 5 / pro)**

## Description
This module disable system camera sounds on whyred.

Tested on LineageOS 15.1 (microG version) android Oreo.
Confirmed working on other AOSP rom.

## Functions

Disable system camera sounds.

## Changelog

v0.1      First build.

## Instructions

Install module in magisk or TWRP (on your choice) and reboot;

## Links
[Module XDA Forum Thread](https://forum.xda-developers.com/redmi-note-5-pro/themes/magisk-miui-camera-v2-port-mods-t3830475 "Module official XDA thread")

[Latest stable Magisk](http://www.tiny.cc/latestmagisk)

## Contributions

