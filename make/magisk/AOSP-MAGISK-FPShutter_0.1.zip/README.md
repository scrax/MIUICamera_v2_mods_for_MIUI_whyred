# **FPShutter for whyred (Redmi note 5 / pro)**

## Description
This module ensbles system wide FP shutter on whyred.

Tested on LineageOS 15.1 (microG version) android Oreo.
Confirmed working on other AOSP rom.

No conflicts with gcam and camera2 API.

## Functions

Enable Fingerprint as shutter button (and select button when not in camera app)

## Changelog

v0.1      First build.

## Instructions

Install module in magisk or TWRP (on your choice) and reboot;

## Links
[Module XDA Forum Thread](https://forum.xda-developers.com/redmi-note-5-pro/themes/magisk-miui-camera-v2-port-mods-t3830475 "Module official XDA thread")

[Latest stable Magisk](http://www.tiny.cc/latestmagisk)

## Contributions

