#!/sbin/sh

dir="/system/media/audio/ui/"

audio_fix() {
	cat <<EOF
camera_click.ogg
camera_focus.ogg
VideoRecord.ogg
VideoStop.ogg
EOF
}

camera_sound_fix(){
	echo 'Starting camera sound fix'
	audio_fix | while read name ;
  		do
    		if [ -f $dir$name.bak ];
      			then
        			echo Camera sound: "$name" already fixed
        			#mv $dir$name.bak $dir$name
      			else
        			echo Fixing camera sound: "$name"
        			mv $dir$name $dir$name.bak
    		fi
		done
}

busybox mount /system
camera_sound_fix