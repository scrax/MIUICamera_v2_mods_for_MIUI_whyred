#!/sbin/sh

bp="/vendor/build.prop"

busybox mount /vendor
busybox mount /data



if [ -f /vendor/build.prop.bak ]; 
  then
    rm -rf $bp
    cp $bp.bak $bp
  else
    cp $bp $bp.bak
fi


echo " " >> $bp

for mod in vendor_build_prop_tweaks;
  do

    for prop in `cat /tmp/$mod`;do
      export newprop=$(echo ${prop} | cut -d '=' -f1)
      sed -i "/${newprop}/d" /vendor/build.prop
      echo $prop >> /vendor/build.prop
    done
done

